package com.example.demojunitteset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemojunittesetApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemojunittesetApplication.class, args);
	}

}
