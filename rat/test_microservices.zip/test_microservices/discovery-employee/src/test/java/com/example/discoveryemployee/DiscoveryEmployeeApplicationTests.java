package com.example.discoveryemployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
